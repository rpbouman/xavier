var muiCssDir = "lib/mui/css/";
var muiImgDir = "lib/mui/images/";
var cssDir = "resources/css/";
var docDir = "resources/doc/";
