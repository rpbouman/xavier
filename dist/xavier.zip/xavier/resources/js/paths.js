var muiCssDir = "../../lib/mui/css/";
var muiImgDir = "../../lib/mui/images/";
var cssDir = "../css/";
//var docDir = "../doc/";
