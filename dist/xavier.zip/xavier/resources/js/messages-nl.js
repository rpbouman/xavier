aMsg({
  //messageboxes
  "Please confirm": "Bevestigen aub",
  "Confirm": "Bevestigen",
  "Cancel": "Annuleren",
  "Ok": "Ok",
  //title:
  "XML/A Visualizer": "XML/A Analyse en Visualizatie",
  //toolbar
  "Refresh metadata": "Ververs metadata",
  "New Query": "Nieuwe zoekopdracht",
  "Open Query": "Zoekopdracht openen",
  "Save Query": "Zoekopdracht opslaan",
  "Save Query As...": "Zoekopdracht opslaan als...",
  "Toggle edit mode": "Bewerkingsmodus aan/uitzetten",
  "Run Query": "Zoekopdracht uitvoeren",
  "Toggle Autorun Query": "Zoekopdracht automatisch uitvoeren aan/uitzetten",
  "Show column hierarchy headers": "Toon kolomkoppen",
  "Show row hierarchy headers": "Toon rijlabels",
  "Export to Microsoft Excel": "Naar Microsoft Excel uitvoeren",
  "New Table": "Nieuwe Tabel",
  "New Pivot Table": "Nieuwe Draaitabel",
  "Welcome!": "Welkom!",
  //excel
  "Nothing to export": "Niets om te exporteren",
  "There is nothing to export. Please enter a query first": "Er kan niets geexporteerd worden. Stel eerst een zoekopdracht samen.",
  "Export Error": "Fout bij exporteren",
  //query
  "Error executing query": "Fout bij uitvoering zoekopdracht",
  //treeview
  "Members": "Leden",
  "Measures": "Meetwaarden",
  "Show catalog nodes": "Schema's tonen",
  "Show dimension nodes": "Dimensies tonen",
  "Check to show multi-hierarchy dimension nodes. Uncheck to hide all dimension nodes.": "Toon de dimensie indien deze meer dan 1 hierarchy heeft.",
  //tab
  "Welcome!": "Welkom!",
  //query designer
  "Columns": "Kolommen",
  "Rows": "Rijen",
  "Slicer": "Selectie"
});